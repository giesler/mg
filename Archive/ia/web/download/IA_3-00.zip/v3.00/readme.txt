README for Install Assistant v3.00
----------------------------------
http://installassistant.com

For full details of this program, please visit the website.

DIRECTORY
\Sample CD - Basic layout of a sample CD
\Settings Utility.exe - Program to modify a VBSW installation image

SYSTEM REQUIREMENTS
- Install Assistant (Autorun.exe) requires Windows 95+ or Windows NT 4.0+
- The 'Settings Utility' requires VB6 runtime files and IE4.0 or higher.