README for VBSW 2.00 BETA
-------------------------
http://giesler.org/vbsw

For full details of this program, please visit the website.

DIRECTORY
\Sample CD - Basic layout of a sample CD
\Settings Utility - Program to modify a VBSW installation image

SYSTEM REQUIREMENTS
- VBSW (Autorun.exe) requires Windows 95+ or Windows NT+
- The 'Settings Utility' requires VB6 runtime files and IE4.0 or higher.